package com.example.guessnumber;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ConfigActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);
    }

    public void getOnClick(View view) {
        switch (view.getId()) {
            case R.id.btnJugar:
                //sendMessage();
                break;
        }
    }

    private void Jugar(){
        Bundle bundle = new Bundle();
        bundle.putString("nombre", binding.edNombre);
    }
}